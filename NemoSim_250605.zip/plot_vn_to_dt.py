import sys
import numpy as np
import matplotlib.pyplot as plt

def read_values(filename):
    with open(filename, 'r') as file:
        values = [float(line.strip()) for line in file]
    return values

def plot_values_over_time(vn_values, vout_values, dt=0.0001):
    time = np.arange(0, len(vn_values) * dt, dt)
    time2 = np.arange(0, len(vn_values) * dt, dt)
    
    plt.figure(figsize=(12, 8))
    
    plt.subplot(2, 1, 1)
    plt.plot(time2, vn_values)
    plt.xlabel('Time (s)')
    plt.ylabel('Current (I_in)')
    plt.title('Input Current Over Time')
    plt.grid(True)
    
    plt.subplot(2, 1, 2)
    plt.plot(time, vout_values)
    plt.xlabel('Time (s)')
    plt.ylabel('Membrane Potential (Vm)')
    plt.title('Membrane Potential Over Time')
    plt.grid(True)
    
    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python script.py <Vns_filename> <Spikes_filename>")
        sys.exit(1)

    Vns_filename = sys.argv[1]
    Spikes_filename = sys.argv[2]
    
    vn_values = read_values(Vns_filename)
    Spikes_values = read_values(Spikes_filename)
    
    plot_values_over_time(vn_values, Spikes_values)
